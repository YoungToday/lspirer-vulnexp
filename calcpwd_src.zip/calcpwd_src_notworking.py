import json
import time
from selenium import webdriver
import requests
from Crypto.Util.Padding import pad
import base64
from base64 import b64decode
from Crypto.Cipher import AES
serviceapi="http://cloud.linspirer.com:880/api/service"
unpad = lambda s: s[:-ord(s[len(s) - 1:])]
def aes_encrypt(key, aes_str):
    vi = "F38AD7ADC6161529"
    aes = AES.new(key.encode('utf-8'), AES.MODE_CBC,vi.encode('utf8'))
    pad_pkcs7 = pad(aes_str.encode('utf-8'), AES.block_size, style='pkcs7')
    encrypt_aes = aes.encrypt(pad_pkcs7)
    encrypted_text = str(base64.encodebytes(encrypt_aes), encoding='utf-8')
    encrypted_text_str = encrypted_text.replace("\n", "")
    return encrypted_text_str
def aes_decrypt(key,text):
    iv = "F38AD7ADC6161529"
    encrypted_text = b64decode(text)
    cipher = AES.new(key=key.encode(), mode=AES.MODE_CBC, IV=iv.encode())
    decrypted_text = cipher.decrypt(encrypted_text)
    return unpad(decrypted_text).decode('utf-8')
def aes_encrypt_new(key, aes_str):
    vi = "5E9B755A8B674394"
    aes = AES.new(key.encode('utf-8'), AES.MODE_CBC,vi.encode('utf8'))
    pad_pkcs7 = pad(aes_str.encode('utf-8'), AES.block_size, style='pkcs7')
    encrypt_aes = aes.encrypt(pad_pkcs7)
    encrypted_text = str(base64.encodebytes(encrypt_aes), encoding='utf-8')
    encrypted_text_str = encrypted_text.replace("\n", "")
    return encrypted_text_str
def aes_decrypt_new(key,text):
    iv = "5E9B755A8B674394"
    encrypted_text = b64decode(text)
    cipher = AES.new(key=key.encode(), mode=AES.MODE_CBC, IV=iv.encode())
    decrypted_text = cipher.decrypt(encrypted_text)
    return unpad(decrypted_text).decode('utf-8')
def checkpass(swdidd):
    data2=aes_encrypt("3901254795DA7CC3", json.dumps({"swdid":swdidd,"schoolid":"127df023-de3d-4bca-b810-b2b51854a064"},separators=(',',':')).encode('unicode_escape').decode())
    dataSS=json.dumps({"id":"1","!version":"1","jsonrpc":"2.0","is_encrypt":"true","client_version":"tongyongshengchan_5.03.002.0","params":data2,"method":"com.linspirer.whitelist.whitepass"})
    try:
        res2=requests.post(url="https://cloud.linspirer.com:883/public-interface.php",data=dataSS)
    except:
        print("网络异常")
        return False
    try:
        print("设备密码为:",json.loads(aes_decrypt("3901254795DA7CC3",res2.text)).get('data').get('adminpass').get('password'))
    except:
        print("未查询到设备密码,请检查设备是否合法")
#-----------------------init_login---------------------
print("后台登录开始............")
email='不告诉你'
password='不告诉你'
cok=""
token=""
def weblogin():
    chrome_options = webdriver.ChromeOptions()
    chrome_options.add_argument('--headless')
    browser = webdriver.Chrome(chrome_options=chrome_options)
    browser.get('http://cloud.linspirer.com:880/login')    
    browser.find_element_by_id('email').send_keys(email)
    browser.find_element_by_id('password').send_keys(password)
    browser.find_element_by_xpath('//*[@id="login-form"]/div[4]/button').click()
    global token 
    token = browser.find_element_by_xpath('/html/head/meta[4]').get_attribute("content")
    global cok
    cookie=browser.get_cookies()
    for i in cookie:    
            if i.get('name') == 'education_cloud_session':
                    cok= i.get('value')
#-----------------------init_login---------------------
def pushmessage(msg,title):
    requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":3,"command":msg,"active":title},"jsonrpc":"2.0"}))
weblogin()
print("cok:"+cok)

print("欢迎使用领创工具箱(废了版)V1.05")
helpmsg="openusb开启usb\nstopusb关闭usb\n4.禁用相机\n5.启用相机\n6.启用蓝牙\n7.关闭蓝牙\n8.启用otg和sd\n9.禁用otg和sd\nreboot:重启设备\nReleaseControl:解控但是不销号\nswdid:重新指定swdid\nLockDevice:锁定设备\nUnlockDevice解锁设备\nFactoryReset恢复出厂\nmsg发信息\nexit退出程序\ninformation用户姓名学校id\nlegalDevice违规设备合法化\nUploadApp上传app"
print(helpmsg)
swdid=""
tag=False
while tag == False:
    swdid=input("swdid:")
    tag=checkpass(swdid)
pushmessage(msg="Your Device has been temporarily taken over by LinspirerToolBox",title="您的设备已经临时由工具箱接管")
while 1:
    code= input("LinspirerToolBox>>")
    if code == 'help':
        print(helpmsg)
    if code == 'UploadApp':
        print("上传app")
        ans1=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_applist","active":1},"jsonrpc":"2.0"}))
        print(ans1.text)
    if code == 'openusb' :
        print("准备开启command_connect_usb")
        ans1=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_connect_usb","active":1},"jsonrpc":"2.0"}))
        print(ans1.text)
    if code == 'stopusb':
        print("准备关闭command_connect_usb")
        ans2=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_connect_usb","active":0},"jsonrpc":"2.0"}))
    if code == '4':
        print("禁用相机")
        ans3=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_camera","active":0},"jsonrpc":"2.0"}))
    if code=='5':
        print("启用相机")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_camera","active":1},"jsonrpc":"2.0"}))
    if code=='6':
        print("蓝牙启动command_bluetooth")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_bluetooth","active":1},"jsonrpc":"2.0"}))
    if code=='7':
        print("蓝牙关闭command_bluetooth")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_bluetooth","active":0},"jsonrpc":"2.0"}))
    if code=='8':
        print("启用command_sdcard_and_otg")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_sdcard_and_otg","active":1},"jsonrpc":"2.0"}))
    if code=='9':
        print("禁用command_sdcard_and_otg")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_sdcard_and_otg","active":0},"jsonrpc":"2.0"}))
    if code == 'reboot':
        print("reboot_device")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_reboot_device","active":0},"jsonrpc":"2.0"}))
    if code =='ReleaseControl':
        print("解控")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_release_control","active":0},"jsonrpc":"2.0"}))
    if code == 'swdid':
        swdid=input("请重新输入swdid:")
        checkpass(swdid)
    if code =='UnlockDevice':
        print("解锁设备")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_workspace","active":1},"jsonrpc":"2.0"}))
    if code =='LockDevice':
        print("锁定设备")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_workspace","active":0},"jsonrpc":"2.0"}))
    if code == 'FactoryReset':
        print("恢复出厂")
        ans4=requests.post(url=serviceapi,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token},data=json.dumps({"id":1,"!version":1,"method":"com.linspirer.push.batchPushBySwdids","params":{"swdid":swdid,"type":1,"command":"command_reset_factory","active":0},"jsonrpc":"2.0"}))
    if code == 'msg':
        title=input("title:")
        msg=input("msg:")
        pushmessage(msg=msg,title=title)
    if code == 'legalDevice':
        ans4=requests.get(url="http://cloud.linspirer.com:880/device/processillegal/"+swdid,cookies={"education_cloud_session":cok},headers={"Content-Type":"application/json","X-Requested-With": "XMLHttpRequest","X-CSRF-TOKEN":token,"Accept":"application/json, text/javascript, */*; q=0.01"})
        if str(json.loads(ans4.text).get('code')) == '0':
            print("成功")
    if code == 'exit':
        exit(0)

'''
'''